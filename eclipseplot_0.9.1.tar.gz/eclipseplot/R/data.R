#' Sample brief dataset for eclipseplot
#' @format A data frame with risk of bias assessments.
"sample_brief"

#' Sample long dataset for eclipseplot
#' @format A longer data frame with 26 studies.
"sample_long"